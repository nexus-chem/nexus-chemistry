# Nexus Chemistry

Static site: `index.html`, `style.css`, `script.js`, `videos.js`, `logo.png`.

## Publish on GitHub Pages
1. Create a repository and upload all the files to the root.
2. Settings > Pages > Source: "Deploy from a branch", Branch: `main`, folder `/ (root)`.
3. The site goes live at `https://<username>.github.io/<repo>/`.

## Add or edit videos
Open `videos.js` on GitHub, click the pencil icon, edit the list, then commit.
